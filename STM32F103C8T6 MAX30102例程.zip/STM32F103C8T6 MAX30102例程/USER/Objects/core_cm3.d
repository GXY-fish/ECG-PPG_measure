.\objects\core_cm3.o: ..\CORE\core_cm3.c
.\objects\core_cm3.o: C:\Users\29038\AppData\Local\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
